# etrobo2017

/written by n.t.

開発言語:C++

AreaManager::コース走行用、ポイント切り替え用
Block::ブロック並べ
Detect::段差検知、壁検知
ETsumou::ET相撲
Linetrace::ライントレース
Locallization::自己位置推定
MotorDrive::走行用
PID::PID制御

app::周期処理用、main実行用


ev3api::基本関数の中身、編集不要
＊HowtouseBTは最初に読むべき

他のファイルは必要なし