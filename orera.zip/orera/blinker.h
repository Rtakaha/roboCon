#ifndef SAMPLE_JSP_H
#define SAMBLE_JPS_H

#include <t_services.h>

#ifndef _MACRO_ONLY

extern void cyc(VP_INT exinf);
extern void tsk_starter(VP_INT exinf);
extern void tsk_balancer(VP_INT exinf);
extern void tsk_lightOn(VP_INT exinf);
extern void tsk_lightOff(VP_INT exinf);
extern void tsk_luminometer(VP_INT exinf);
extern void tsk_logger(VP_INT exinf);

#endif	/* _MACRO_ONLY */
#endif	/* SAMPLE_JSP_H */
